# <app>/templatetags/relationList.py
from django import template

register = template.Library()
